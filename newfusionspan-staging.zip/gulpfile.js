const gulp         = require('gulp'),
      concat       = require('gulp-concat'),
      sass         = require('gulp-sass'),
      debug        = require('gulp-debug'),
      autoprefixer = require('gulp-autoprefixer'),
      sourcemaps   = require('gulp-sourcemaps');

// Handle errors
function errorHandler (error) {
    console.log(error.toString());
    this.emit('end');
}

gulp.task('sass', function () {
    return gulp
    .src('wp-content/themes/fusionspan/css/theme.scss')
    .pipe(sourcemaps.init())
    .pipe(debug())
    .on('error', errorHandler)
    .pipe(sass({outputStyle: 'compressed'}).on('error', sass.logError))
    //.pipe(autoprefixer())
    .pipe(sourcemaps.write('./'))
    .pipe(gulp.dest('wp-content/themes/fusionspan/css/'))
});

gulp.task('watch', function () {
    //gulp.watch('wp-content/themes/scsstheme1/css/*.scss', ['sass']);
    gulp.watch('wp-content/themes/fusionspan/css/*.scss', gulp.series('sass'));  // 
});

gulp.task('default', gulp.series('sass'));