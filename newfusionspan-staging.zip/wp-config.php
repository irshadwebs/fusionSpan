<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_fs' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'PUb[mA@cc5%VEbU+M[6A%~gs5|Hoab6H4Gdehj+Wd:=v!j,^C3PUzlSpgIN5lk}<' );
define( 'SECURE_AUTH_KEY',  ',&z^Sp47,#3(GNN>ial.2nKP^}}4RC]${N<YqApk^<NxC-}]~Hg`yI9GM3z`fDN+' );
define( 'LOGGED_IN_KEY',    'd_LR5+Tv> $qZ}W}u9 98:VAub$-Y`.K*0v{5)MNwcp@+~3a`K7C!`/19R_$:jl[' );
define( 'NONCE_KEY',        '9?p!f8oQAlx[Xsjr47?a5->JkxUdKwTkfV~{%ytI=PRa|1:L#j4Et*0#l]njEQ~Z' );
define( 'AUTH_SALT',        '^&JQqht@_Fz!9tpG5OlILFymGATOd2NSSv|@0Gvks@:Mw-iBeghpx~z<LLf>7;ak' );
define( 'SECURE_AUTH_SALT', 'l=FVx5GV|jfb-e[i9.%eV)ux>gOOP`K!>0fB{u{HCAIY[J~`b1EFK*7qh^vvs(c}' );
define( 'LOGGED_IN_SALT',   'A-#]iV8sbY~C$dHJ`/Nx~R|Xi-:d>~Bn|ASr/B@}^X4jw{}nthQX8E(4$D/`:s2M' );
define( 'NONCE_SALT',       'v #CL[H%KyY3[o,~.R17-Cn%fhFsVHnm(NM9z%Q9QC:jQb}SPsLTo3/Xsy<@:Mv>' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

define( 'ALLOW_UNFILTERED_UPLOADS', true );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
